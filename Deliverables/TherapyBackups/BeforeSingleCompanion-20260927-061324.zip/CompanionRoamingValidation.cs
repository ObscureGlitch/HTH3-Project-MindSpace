using System;
using System.IO;
using System.Linq;
using System.Text;
using TheLastWatch.Integrations;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

namespace TherapyGame.Editor
{
    [InitializeOnLoad]
    public static class CompanionRoamingValidation
    {
        private const string Root="Assets/TherapyGame",Folder=Root+"/Characters/Roaming";
        private const string Request=Root+"/CompanionRoamingValidationRequest.txt";
        static CompanionRoamingValidation()
        {
            EditorApplication.delayCall+=Once;
            EditorApplication.playModeStateChanged+=state=>{if(state==PlayModeStateChange.EnteredEditMode)EditorApplication.delayCall+=Once;};
        }
        private static void Once()
        {
            if(!File.Exists(Request)||File.ReadAllText(Request).Trim()!="verify-roaming-once")return;
            if(EditorApplication.isCompiling||EditorApplication.isUpdating){EditorApplication.delayCall+=Once;return;}
            if(EditorApplication.isPlayingOrWillChangePlaymode)return;
            File.WriteAllText(Request,"checking");
            try{Verify();File.WriteAllText(Request,"passed");}
            catch(Exception e){File.WriteAllText(Request,"failed");File.WriteAllText(Folder+"/RoamingValidation.txt",e.ToString());Debug.LogException(e);}
        }

        [MenuItem("Therapy Game/Verify Roaming Companions")]
        public static void Verify()
        {
            if(EditorApplication.isPlayingOrWillChangePlaymode)throw new InvalidOperationException("Verify in Edit mode.");
            Scene scene=SceneManager.GetSceneByPath(Root+"/Scenes/TherapyRoom.unity");
            var room=scene.GetRootGameObjects().Single(go=>go.name=="TherapyRoom");
            var chat=room.GetComponentInChildren<WellnessVoiceChat>(true);
            var navigation=room.GetComponentInChildren<WellnessCompanionNavigation>(true);
            if(chat==null||navigation==null||navigation.data==null||!chat.proximityConversations||chat.showOnlySelected)
                throw new InvalidOperationException("Roaming configuration is incomplete.");
            var report=new StringBuilder();
            NavMeshDataInstance probe=NavMesh.AddNavMeshData(navigation.data);
            try
            {
                // The saved indoor spawn is a floor sample; a ray through its standing model hits its head.
                if(!NavMesh.SamplePosition(chat.therapists[0].transform.position,out var indoor,.8f,NavMesh.AllAreas))
                    throw new InvalidOperationException("Indoor spawn is not on the navigation surface.");
                if(!navigation.destinations.Any(p=>Vector3.Distance(p,indoor.position)<.5f))
                {
                    Undo.RecordObject(navigation,"Include return visits to the room");
                    navigation.destinations=navigation.destinations.Concat(new[]{indoor.position}).ToArray();
                    EditorUtility.SetDirty(navigation);EditorSceneManager.MarkSceneDirty(scene);
                }
                var route=new NavMeshPath();int pairs=0;
                foreach(Vector3 a in navigation.destinations)foreach(Vector3 b in navigation.destinations)
                {
                    if(a==b)continue;
                    if(!NavMesh.CalculatePath(a,b,NavMesh.AllAreas,route)||route.status!=NavMeshPathStatus.PathComplete)
                        throw new InvalidOperationException("No complete route from "+a+" to "+b);
                    foreach(var p in route.corners)
                    {
                        if(p.x<-11.5f||p.x>31.5f||p.z<-21.5f||p.z>15.5f)throw new InvalidOperationException("Path crosses map bounds.");
                        if(p.x>8.4f&&p.x<21.6f&&p.z>-10.6f&&p.z<.6f)throw new InvalidOperationException("Path enters the pond exclusion.");
                    }
                    pairs++;
                }
                report.AppendLine("PASS: "+pairs+" directed routes between "+navigation.destinations.Length+" destinations, including return visits to the room; all routes stay inside the map and outside the pond.");
                foreach(var actor in chat.therapists)
                {
                    var movement=actor.movement;var agent=actor.GetComponent<NavMeshAgent>();
                    if(!actor.gameObject.activeSelf||movement==null||agent==null||movement.agent!=agent||movement.actor!=actor||movement.navigation!=navigation||movement.door!=chat.entranceDoor)
                        throw new InvalidOperationException("Broken movement references for "+actor.characterName);
                    if(agent.enabled||agent.radius!=.29f||agent.height!=1.9f||agent.autoTraverseOffMeshLink)
                        throw new InvalidOperationException("Unexpected agent settings for "+actor.characterName);
                    if(actor.bodyAnimation==null||actor.bodyAnimation["Walk"]==null||actor.faceRenderer.sharedMesh.blendShapeCount!=5)
                        throw new InvalidOperationException("Walking animation or live mouth shapes missing.");
                    if(!NavMesh.SamplePosition(actor.transform.position,out var spawn,.2f,NavMesh.AllAreas))
                        throw new InvalidOperationException("Companion spawn is off navigation.");
                    report.AppendLine("PASS: "+actor.characterName+" is visible, has a valid floor spawn, linked movement/agent/navigation/door, supplied Walk animation and five live vowel shapes.");
                }
                if(Vector3.Distance(chat.therapists[0].transform.position,chat.therapists[1].transform.position)<1.5f)
                    throw new InvalidOperationException("Companion spawn positions overlap.");
                if(chat.entranceDoor.companions.Length!=2||chat.entranceDoor.companions.Any(c=>c==null))
                    throw new InvalidOperationException("Door protection is missing companion colliders.");
                // Existing consent object is exercised without creating a provider or accessing a device.
                var consent=new WellnessVoiceConsent();
                if(consent.CanConnect(true,true,false))throw new InvalidOperationException("Consent unexpectedly granted.");
                consent.Choose(false);if(consent.CanConnect(true,true,false))throw new InvalidOperationException("Voice-off path did not hold.");
                consent.Choose(true);consent.Pause();if(consent.CanConnect(true,true,false))throw new InvalidOperationException("Pause did not hold.");
                consent.Resume();consent.SetMuted(true);if(consent.CanConnect(true,true,false))throw new InvalidOperationException("Mute did not hold.");
                report.AppendLine("PASS: separated spawns, both door safety colliders, voice off, pause and mute behavior.");
            }
            finally{if(probe.valid)probe.Remove();}
            if(scene.isDirty&&!EditorSceneManager.SaveScene(scene))throw new IOException("Could not save the room return destination.");
            File.WriteAllText(Folder+"/RoamingValidation.txt",report+"Edit-mode verification only; no microphone or provider session was used.\n");
            Debug.Log("THERAPY_COMPANION_ROAMING_VERIFIED: "+report);
        }
    }
}
