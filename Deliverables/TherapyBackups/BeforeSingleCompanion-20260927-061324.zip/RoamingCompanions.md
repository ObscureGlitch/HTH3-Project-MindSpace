# Roaming companions

Julien and Camille are both present in the world. They explore connected destinations around the room and garden, take short breaks, and pause when the player approaches. Press **E** while looking at a companion to open their controls and talk if voice consent has been granted. Voice remains optional.

Open **V → Companions** to choose **Follow me**, **Stay here**, or **Explore** for either or both characters. Following works with voice disabled. Followers start catching up beyond 3 m and stop inside 1.9 m, with separate side offsets. They can continue a conversation while walking. Staying or exploring can be selected at any time.

The supplied `Walk` clip follows actual movement speed; stationary conversation clips and real-time vowel lip-sync resume when stopped. Only the selected companion receives conversation gestures. Roaming destinations are visited in a fixed sequence, with different starting points for each character.

Navigation is baked from the live level's solid colliders, with a 0.29 m agent radius, 1.9 m clearance, 35-degree slope limit, and 0.22 m steps. Companions use dry routes around the pond and remain inside the fenced map. Runtime capsule sweeps protect against the player, other companions, and the moving door. Companions open the door as they approach; the door checks their colliders throughout its swing. Unreachable destinations cause waiting or another exploration choice; following never teleports a character.

Conversations use a 6 m distance from the companion's current head position and require a clear line through the level. Audio follows the moving character. A wall or closed door interrupts hearing. Press E or the Talk button to request a conversation; consent alone does not open a microphone session for passing walkers. Existing mute, pause, consent and session limits remain in effect.

The installer backs up the open scene, checks follow hysteresis and pause decisions, and verifies complete paths between every exploration destination, including the room-to-garden doorway connection. `Characters/Roaming/RoamingCheck.txt` records installation results. `Deliverables/CheckCompanionRoaming.ps1` compiles runtime and editor code against the installed Unity dependencies.

After Unity refreshes in Edit mode, the queued validation includes the indoor return destination and checks all 132 directed routes among 12 stops, actor/door references, walking clips, and voice-off/mute/pause behavior without opening the microphone. Its result is recorded in `Characters/Roaming/RoamingValidation.txt`. It can also be run from **Therapy Game → Verify Roaming Companions**. Runtime movement still needs a Play-mode check; a source compilation or route audit alone does not confirm it.
