using UnityEngine;
using UnityEngine.Rendering;

namespace TheLastWatch.Environment
{
    /// <summary>Restrained distance haze, scoped to this camera instead of the whole project.</summary>
    [ExecuteAlways, RequireComponent(typeof(Camera)), DisallowMultipleComponent]
    public sealed class WellnessAtmosphere : MonoBehaviour
    {
        [Range(0f, .08f)] public float density = .032f;
        public Color hazeColor = new Color(.87f, .73f, .58f, 1f);
        public bool hazeEnabled = true;
        public bool gardenTransition;
        public float outdoorDensity = .009f;
        public Color outdoorHazeColor = new Color(.74f, .83f, .81f, 1);
        private Camera _camera;
        private bool _applied, _oldFog;
        private FogMode _oldMode;
        private Color _oldColor;
        private float _oldDensity, _oldStart, _oldEnd;
        private void OnEnable()
        {
            _camera = GetComponent<Camera>();
            RenderPipelineManager.beginCameraRendering += BeginCamera;
            RenderPipelineManager.endCameraRendering += EndCamera;
        }
        private void OnDisable()
        {
            RenderPipelineManager.beginCameraRendering -= BeginCamera;
            RenderPipelineManager.endCameraRendering -= EndCamera;
            Restore();
        }
        private void BeginCamera(ScriptableRenderContext context, Camera camera)
        {
            if (camera != _camera || !hazeEnabled || _applied) return;
            _oldFog = RenderSettings.fog; _oldMode = RenderSettings.fogMode;
            _oldColor = RenderSettings.fogColor; _oldDensity = RenderSettings.fogDensity;
            _oldStart = RenderSettings.fogStartDistance; _oldEnd = RenderSettings.fogEndDistance;
            _applied = true;
            RenderSettings.fog = true; RenderSettings.fogMode = FogMode.ExponentialSquared;
            Vector3 p = camera.transform.position;
            float outside = gardenTransition ? Mathf.SmoothStep(0, 1, Mathf.Max(Mathf.Abs(p.x) - 3.6f, Mathf.Abs(p.z) - 3.1f) / 2.5f) : 0;
            RenderSettings.fogColor = Color.Lerp(hazeColor, outdoorHazeColor, outside);
            RenderSettings.fogDensity = Mathf.Lerp(density, outdoorDensity, outside);
        }
        private void EndCamera(ScriptableRenderContext context, Camera camera) { if (camera == _camera) Restore(); }
        private void Restore()
        {
            if (!_applied) return;
            RenderSettings.fog = _oldFog; RenderSettings.fogMode = _oldMode;
            RenderSettings.fogColor = _oldColor; RenderSettings.fogDensity = _oldDensity;
            RenderSettings.fogStartDistance = _oldStart; RenderSettings.fogEndDistance = _oldEnd;
            _applied = false;
        }
    }
}
