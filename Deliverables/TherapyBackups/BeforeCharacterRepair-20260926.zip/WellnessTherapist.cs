using UnityEngine;

namespace TheLastWatch.Integrations
{
    // The supplied GLBs have rigid articulated parts, not humanoid animation clips.
    // These small joint offsets layer on top of the saved seated pose; no IK or cloth simulation.
    [DisallowMultipleComponent]
    public sealed class WellnessTherapist : MonoBehaviour
    {
        public string characterName;
        public int voiceIndex;
        public WellnessVoiceChat chat;
        public Transform voiceAnchor, head, spine, lowerLip, lowerTeeth, tongue;
        public string Prompt => "Talk to " + characterName + " / choose companion";
        private Quaternion headRest, spineRest;
        private Vector3 lipRest, teethRest, tongueRest;
        private float speech;
        private void Awake()
        {
            if(head!=null)headRest=head.localRotation;
            if(spine!=null)spineRest=spine.localRotation;
            if(lowerLip!=null)lipRest=lowerLip.localPosition;
            if(lowerTeeth!=null)teethRest=lowerTeeth.localPosition;
            if(tongue!=null)tongueRest=tongue.localPosition;
        }
        public string Interact()
        {
            if(chat==null)return "Voice controls are not configured.";
            chat.OpenFor(voiceIndex);
            return "Choose Julien or Camille, then agree and Start. No recording begins until you Start.";
        }
        private void LateUpdate()
        {
            if(chat==null||chat.player==null||chat.player.ViewCamera==null)return;
            float t=Time.time;
            bool nearby=(chat.player.ViewCamera.transform.position-voiceAnchor.position).sqrMagnitude<100;
            float speaking=chat.IsSpeakingWith(voiceIndex)?1:0;
            speech=Mathf.MoveTowards(speech,speaking,Time.deltaTime*5);
            if(spine!=null)spine.localRotation=spineRest*Quaternion.Euler(nearby?Mathf.Sin(t*1.35f)*.35f:0,0,0);
            Quaternion look=headRest;
            if(nearby&&head!=null)
            {
                Vector3 direction=head.parent.InverseTransformDirection(chat.player.ViewCamera.transform.position-head.position).normalized;
                float yaw=Mathf.Clamp(Mathf.Atan2(direction.x,direction.z)*Mathf.Rad2Deg,-22,22);
                float pitch=Mathf.Clamp(-Mathf.Asin(Mathf.Clamp(direction.y,-1,1))*Mathf.Rad2Deg,-10,12);
                look=headRest*Quaternion.Euler(pitch+speech*Mathf.Sin(t*2.1f)*1.2f,yaw,0);
            }
            if(head!=null)head.localRotation=Quaternion.Slerp(head.localRotation,look,1-Mathf.Exp(-Time.deltaTime*3));
            float mouth=speech*(.35f+.65f*Mathf.Abs(Mathf.Sin(t*10.7f)*Mathf.Cos(t*3.2f)));
            // Restrained speech cue, not phoneme-accurate lip sync. The full lips mesh moves only 1 mm.
            if(lowerLip!=null)lowerLip.localPosition=lipRest+Vector3.down*(mouth*.001f);
            if(lowerTeeth!=null)lowerTeeth.localPosition=teethRest+Vector3.down*(mouth*.003f);
            if(tongue!=null)tongue.localPosition=tongueRest+Vector3.down*(mouth*.002f);
        }
    }
}
