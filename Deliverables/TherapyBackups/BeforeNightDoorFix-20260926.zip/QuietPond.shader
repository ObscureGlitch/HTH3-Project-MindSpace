Shader "Therapy Game/Quiet Pond"
{
    Properties
    {
        _BaseColor ("Deep teal", Color) = (0.12, 0.39, 0.42, 1)
        _ShoreColor ("Shallow water", Color) = (0.38, 0.64, 0.57, 1)
        _SkyTint ("Soft sky sheen", Color) = (0.60, 0.76, 0.77, 1)
        _Pond ("Centre XZ / radii XZ", Vector) = (15, -5, 6.7, 5.7)
        _Opacity ("Water tint opacity", Range(0, 1)) = 0.64
        _RippleStrength ("Ripple strength", Range(0, 0.2)) = 0.055
    }
    SubShader
    {
        Tags { "RenderPipeline"="UniversalPipeline" "RenderType"="Transparent" "Queue"="Transparent" }
        Pass
        {
            Name "QuietPondForward"
            Tags { "LightMode"="UniversalForward" }
            Blend SrcAlpha OneMinusSrcAlpha
            ZWrite Off
            Cull Back
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_fog
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE
            #define _SURFACE_TYPE_TRANSPARENT 1
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _BaseColor;
                half4 _ShoreColor;
                half4 _SkyTint;
                float4 _Pond;
                half _Opacity;
                half _RippleStrength;
            CBUFFER_END
            struct Attributes { float4 positionOS : POSITION; };
            struct Varyings { float4 positionCS : SV_POSITION; float3 positionWS : TEXCOORD0; half fog : TEXCOORD1; };
            Varyings Vert(Attributes input)
            {
                Varyings output;
                output.positionWS = TransformObjectToWorld(input.positionOS.xyz);
                output.positionCS = TransformWorldToHClip(output.positionWS);
                output.fog = ComputeFogFactor(output.positionCS.z);
                return output;
            }
            half4 Frag(Varyings input) : SV_Target
            {
                // Two travelling ripple directions; no normal textures, refraction
                // buffer, reflection camera, vertex deformation, or extra passes.
                float2 p = input.positionWS.xz;
                float a = dot(p, float2(2.7, 1.8)) + _Time.y * 1.05;
                float b = dot(p, float2(-1.5, 3.4)) - _Time.y * 0.78;
                float c = dot(p, float2(6.1, -4.2)) + _Time.y * 1.36;
                float2 slope = float2(0.84, 0.56) * cos(a)
                    + float2(-0.40, 0.91) * cos(b) * 0.65
                    + float2(0.82, -0.57) * cos(c) * 0.22;
                half3 n = normalize(half3(-slope.x * _RippleStrength, 1, -slope.y * _RippleStrength));
                half3 view = GetWorldSpaceNormalizeViewDir(input.positionWS);
                half fresnel = pow(1 - saturate(dot(n, view)), 4);
                float shoreDistance = length((p - _Pond.xy) / _Pond.zw);
                half shore = smoothstep(0.55, 1.0, shoreDistance);
                half3 tint = lerp(_BaseColor.rgb, _ShoreColor.rgb, shore * 0.75);
                tint += (sin(a) * sin(b) * 0.012);
                Light sun = GetMainLight(TransformWorldToShadowCoord(input.positionWS));
                half lighting = 0.76 + 0.24 * saturate(dot(n, sun.direction)) * sun.shadowAttenuation;
                half3 water = tint * lighting;
                water = lerp(water, _SkyTint.rgb, 0.10 + fresnel * 0.50);
                half3 halfDirection = SafeNormalize(sun.direction + view);
                half glint = pow(saturate(dot(n, halfDirection)), 96) * 0.24 * sun.shadowAttenuation;
                water += min(sun.color, half3(1.5, 1.5, 1.5)) * glint;
                half alpha = lerp(_Opacity, 0.87, fresnel) * (1 - smoothstep(0.97, 1.0, shoreDistance) * 0.48);
                return half4(MixFog(water, input.fog), alpha);
            }
            ENDHLSL
        }
    }
    FallBack Off
}
