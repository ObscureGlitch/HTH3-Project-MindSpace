using System;
using UnityEngine;

namespace TheLastWatch.UI
{
    // Small cached nine-slice textures; translucency without blur, extra cameras or post-processing.
    public sealed class WellnessUiTheme : IDisposable
    {
        public static readonly Color Ink=new Color(.19f,.23f,.20f),Muted=new Color(.40f,.44f,.39f),Sage=new Color(.36f,.53f,.41f);
        public readonly GUIStyle Panel,Shadow,Text,Small,Heading,Title,Button,Key,Tag;
        private readonly Texture2D card,shadow,button,hover,key,dot;
        public WellnessUiTheme()
        {
            card=Round(new Color(.94f,.925f,.885f,.90f));shadow=Round(new Color(.09f,.14f,.11f,.09f));
            button=Round(new Color(.995f,.99f,.96f,.88f));hover=Round(new Color(.81f,.87f,.81f,.98f));key=Round(new Color(1,1,.99f,.96f));dot=Round(Color.white,32);
            Panel=Box(card);Shadow=Box(shadow);
            Text=Label(17,Ink);Small=Label(12,Muted);Heading=Label(13,Ink,FontStyle.Bold);Title=Label(25,Ink,FontStyle.Bold);
            Button=new GUIStyle(GUI.skin.button){fontSize=14,richText=false,wordWrap=true,border=new RectOffset(16,16,16,16),padding=new RectOffset(8,8,4,4)};
            Button.normal.background=button;Button.hover.background=hover;Button.active.background=hover;
            Button.focused.background=hover;Button.normal.textColor=Button.hover.textColor=Button.active.textColor=Button.focused.textColor=Ink;
            Button.onNormal.background=Button.onHover.background=Button.onActive.background=Button.onFocused.background=hover;
            Button.onNormal.textColor=Button.onHover.textColor=Button.onActive.textColor=Button.onFocused.textColor=Ink;
            Key=Box(key);Key.fontSize=11;Key.alignment=TextAnchor.MiddleCenter;Key.normal.textColor=Ink;
            Tag=Label(10,Muted,FontStyle.Bold);
        }
        private static GUIStyle Label(int size,Color color,FontStyle weight=FontStyle.Normal)=>
            new GUIStyle(GUI.skin.label){fontSize=size,fontStyle=weight,richText=false,wordWrap=true,normal={textColor=color},padding=new RectOffset(0,0,0,0)};
        private static GUIStyle Box(Texture2D texture)=>new GUIStyle{normal={background=texture},border=new RectOffset(16,16,16,16)};
        private static Texture2D Round(Color color,float radius=14)
        {
            const int n=64;var texture=new Texture2D(n,n,TextureFormat.RGBA32,false){hideFlags=HideFlags.HideAndDontSave,filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
            var pixels=new Color[n*n];
            for(int y=0;y<n;y++)for(int x=0;x<n;x++)
            {
                float dx=Mathf.Max(Mathf.Abs(x+.5f-n*.5f)-(n*.5f-radius),0),dy=Mathf.Max(Mathf.Abs(y+.5f-n*.5f)-(n*.5f-radius),0);
                Color c=color;c.a*=Mathf.Clamp01(radius+.5f-Mathf.Sqrt(dx*dx+dy*dy));pixels[y*n+x]=c;
            }
            texture.SetPixels(pixels);texture.Apply(false,true);return texture;
        }
        public void Card(Rect r,float opacity=1)
        {
            GUI.Box(new Rect(r.x,r.y+3,r.width,r.height),GUIContent.none,Shadow);
            Color old=GUI.color;GUI.color=new Color(old.r,old.g,old.b,old.a*opacity);GUI.Box(r,GUIContent.none,Panel);GUI.color=old;
        }
        public void Dot(Rect r,Color color){Color old=GUI.color;GUI.color=color;GUI.DrawTexture(r,dot);GUI.color=old;}
        public static void Fill(Rect r,Color color){Color old=GUI.color;GUI.color=color;GUI.DrawTexture(r,Texture2D.whiteTexture);GUI.color=old;}
        public void Dispose(){foreach(var t in new[]{card,shadow,button,hover,key,dot})if(t!=null)UnityEngine.Object.Destroy(t);}
    }
}
