using System;
using System.Collections.Generic;
using TheLastWatch.Audio;
using TheLastWatch.Integrations;
using TheLastWatch.Interaction;
using TheLastWatch.Player;
using UnityEngine;
using UnityEngine.InputSystem;

namespace TheLastWatch.UI
{
    public struct WellnessHudLayout
    {
        public Rect journey,settings,music,captions,interaction;
        public static WellnessHudLayout At(float width,float height,bool largeCaptions=false)=>new WellnessHudLayout
        {
            journey=new Rect(28,24,300,178),settings=new Rect(width-174,24,146,40),
            music=new Rect(28,height-122,262,96),captions=new Rect((width-570)/2,height-(largeCaptions?204:176),570,largeCaptions?178:150),
            interaction=new Rect((width-340)/2,height*.535f,340,38)
        };
    }

    [DisallowMultipleComponent]
    public sealed class WellnessHud : MonoBehaviour
    {
        public WellnessVoiceChat chat;
        public WellnessExplorer player;
        public Transform room;
        [Range(.65f,1)] public float panelOpacity=1;
        public bool showJourney=true,showCaptions=true,largerCaptions;
        private bool collapsed,settled,talked,breathed;
        private float settledTime;
        private readonly HashSet<WellnessInteraction> noticed=new HashSet<WellnessInteraction>();
        private WellnessInteraction[] interactions=Array.Empty<WellnessInteraction>();
        private WellnessUiTheme theme;
        private GUIStyle largeCaption;
        private Vector2 captionScroll;
        private string lastCaption;
        public WellnessUiTheme Theme=>theme??(theme=new WellnessUiTheme()); // Accessed only inside OnGUI.
        public int JourneyCompleted=>(settled?1:0)+(talked?1:0)+(breathed?1:0)+(noticed.Count>=3?1:0);
        private void OnEnable()
        {
            if(!Application.isPlaying)return;
            settled=talked=breathed=collapsed=false;noticed.Clear();settledTime=0;
            if(room!=null){interactions=room.GetComponentsInChildren<WellnessInteraction>(true);foreach(var item in interactions)item.Noticed+=OnNoticed;}
            if(chat!=null)chat.UserCaptionReceived+=OnUserCaption;
        }
        private void OnDisable()
        {
            foreach(var item in interactions)if(item!=null)item.Noticed-=OnNoticed;
            if(chat!=null)chat.UserCaptionReceived-=OnUserCaption;
        }
        private void OnDestroy(){theme?.Dispose();theme=null;}
        private void OnUserCaption()=>talked=true;
        private void OnNoticed(WellnessInteraction item)
        {
            if(item.breathingOrb!=null)breathed=true;
            else if(item.area==WellnessInteraction.Area.Grounding&&item.door==null&&item.therapist==null)noticed.Add(item);
        }
        private void Update()
        {
            if(!Application.isPlaying||chat==null||player==null||chat.IsPanelOpen)return;
            if(!settled&&room!=null&&player.ViewCamera!=null&&chat.localRoom.Contains(room.InverseTransformPoint(player.ViewCamera.transform.position)))
            {settledTime+=Time.unscaledDeltaTime;if(settledTime>=5||player.IsSeated)settled=true;}
            var keyboard=Keyboard.current;if(keyboard==null)return;
            if(keyboard.jKey.wasPressedThisFrame)collapsed=!collapsed;
            if(keyboard.pKey.wasPressedThisFrame)BackgroundMusicPlayer.Instance?.TogglePause();
        }
        private void OnGUI()
        {
            if(!Application.isPlaying||chat==null||player==null||chat.IsPanelOpen)return;
            var ui=Theme;float scale=Mathf.Min(Screen.width/1280f,Screen.height/720f);if(scale<=0)return;
            Matrix4x4 old=GUI.matrix;int oldDepth=GUI.depth;GUI.depth=0;GUI.matrix=Matrix4x4.Scale(new Vector3(scale,scale,1));
            float width=Screen.width/scale,height=Screen.height/scale;var layout=WellnessHudLayout.At(width,height,largerCaptions);
            try
            {
                if(showJourney)DrawJourney(layout.journey);
                ui.Card(layout.settings,panelOpacity);
                if(GUI.Button(new Rect(layout.settings.x+8,layout.settings.y+5,layout.settings.width-16,30),"Settings   F1",ui.Button))chat.OpenSettings();
                DrawMusic(layout.music);
                DrawInteraction(layout.interaction,width,height);
                if(showCaptions)DrawCaptions(layout.captions);
                // Microphone state is never hidden with captions/checklist preferences.
                Rect mic=new Rect(width-272,76,244,32);ui.Card(mic,panelOpacity);
                ui.Dot(new Rect(mic.x+12,mic.y+12,8,8),chat.IsConnected&&!chat.IsMuted?WellnessUiTheme.Sage:WellnessUiTheme.Muted);
                GUI.Label(new Rect(mic.x+28,mic.y+8,208,22),chat.MicrophoneBadge,ui.Small);
                if(!showCaptions&&GUI.Button(new Rect(width-272,114,244,31),"Voice controls   V",ui.Button))chat.OpenPanel();
                if(!string.IsNullOrEmpty(player.NoticeMessage))
                {
                    Rect notice=new Rect(layout.captions.x,layout.captions.y-90,layout.captions.width,76);ui.Card(notice,panelOpacity);
                    GUI.Label(new Rect(notice.x+18,notice.y+12,notice.width-36,55),player.NoticeMessage,ui.Text);
                }
                if(player.TransitionFade>0)WellnessUiTheme.Fill(new Rect(0,0,width,height),new Color(.04f,.05f,.04f,player.TransitionFade));
            }
            finally{GUI.matrix=old;GUI.depth=oldDepth;}
        }
        private void DrawJourney(Rect r)
        {
            var ui=Theme;if(collapsed)r.height=43;ui.Card(r,panelOpacity);
            GUI.Label(new Rect(r.x+16,r.y+14,178,21),"When you're ready  "+JourneyCompleted+"/4",ui.Heading);
            if(GUI.Button(new Rect(r.x+r.width-61,r.y+8,47,27),collapsed?"J  +":"J  −",ui.Button))collapsed=!collapsed;
            if(collapsed)return;
            Row(r,50,settled,"Settle into the room");
            Row(r,77,talked,"Tell your guide how today felt");
            GUI.Label(new Rect(r.x+34,r.y+97,r.width-48,18),"A word or two is plenty. No rush.",ui.Small);
            Row(r,121,breathed,"Try the breathing orb");
            Row(r,149,noticed.Count>=3,"Notice three things in the room  "+Mathf.Min(3,noticed.Count)+"/3");
        }
        private void Row(Rect r,float y,bool done,string label)
        {
            var ui=Theme;ui.Dot(new Rect(r.x+16,r.y+y-2,9,9),done?WellnessUiTheme.Sage:WellnessUiTheme.Muted);
            if(!done)ui.Dot(new Rect(r.x+18,r.y+y,5,5),new Color(.94f,.925f,.885f));
            GUI.Label(new Rect(r.x+34,r.y+y-6,r.width-46,25),label,ui.Small);
        }
        private void DrawMusic(Rect r)
        {
            var ui=Theme;var music=BackgroundMusicPlayer.Instance;ui.Card(r,panelOpacity);
            GUI.Label(new Rect(r.x+40,r.y+13,154,16),music==null?"AMBIENCE":music.IsPaused?"MUSIC PAUSED":"NOW PLAYING",ui.Tag);
            GUI.Label(new Rect(r.x+40,r.y+31,168,19),music!=null?music.TrackTitle:"Room sounds",ui.Heading);
            GUI.Label(new Rect(r.x+40,r.y+52,177,19),music!=null?"Room playlist · "+music.TrackNumber+" of "+music.TrackCount:"No music track loaded",ui.Small);
            for(int i=0;i<4;i++)
            {
                float h=music!=null&&music.IsPlaying?8+(Mathf.Sin(Time.unscaledTime*(2+i*.31f)+i)*.5f+.5f)*14:6+i*3;
                WellnessUiTheme.Fill(new Rect(r.x+15+i*5,r.y+48-h,3,h),WellnessUiTheme.Sage);
            }
            GUI.enabled=music!=null;if(GUI.Button(new Rect(r.x+r.width-44,r.y+18,30,28),"P",ui.Button))music.TogglePause();GUI.enabled=true;
            float duration=music!=null?music.Duration:0,elapsed=music!=null?music.Elapsed:0;
            GUI.Label(new Rect(r.x+14,r.y+74,38,17),TimeLabel(elapsed),ui.Tag);
            GUI.Label(new Rect(r.x+r.width-43,r.y+74,38,17),TimeLabel(duration),ui.Tag);
            Rect track=new Rect(r.x+54,r.y+81,r.width-104,2);WellnessUiTheme.Fill(track,new Color(.57f,.60f,.54f,.28f));
            track.width*=duration>0?Mathf.Clamp01(elapsed/duration):0;WellnessUiTheme.Fill(track,WellnessUiTheme.Sage);
        }
        private void DrawInteraction(Rect r,float width,float height)
        {
            var ui=Theme;
            if(!player.CursorReleased&&!player.IsTransitioning)ui.Dot(new Rect(width/2-2,height/2-2,4,4),new Color(1,1,.95f,.85f));
            string prompt=player.HudPrompt;if(string.IsNullOrEmpty(prompt))return;
            ui.Card(r,panelOpacity);GUI.Box(new Rect(r.x+9,r.y+7,45,24),player.HudPromptKey,ui.Key);
            GUI.Label(new Rect(r.x+66,r.y+10,r.width-74,27),prompt,ui.Small);
        }
        private void DrawCaptions(Rect r)
        {
            var ui=Theme;ui.Card(r,panelOpacity);var captions=chat.Captions;
            bool user=chat.IsConnected&&(captions.Who==WellnessCaptions.Speaker.Player||captions.Who==WellnessCaptions.Speaker.Listening);
            string name=user?"You":chat.GuideName;
            ui.Dot(new Rect(r.x+18,r.y+19,9,9),user?new Color(.54f,.62f,.70f):WellnessUiTheme.Sage);
            GUI.Label(new Rect(r.x+38,r.y+16,112,21),name,ui.Heading);
            GUI.Label(new Rect(r.x+152,r.y+18,164,19),user?"YOUR VOICE": "AI COMPANION",ui.Tag);
            if(chat.IsConnected&&captions.Pages.Length>1)GUI.Label(new Rect(r.x+r.width-66,r.y+18,50,18),(captions.Page+1)+" / "+captions.Pages.Length,ui.Tag);
            string body=chat.IsConnected?captions.Pages[captions.Page]:chat.IsBusy?chat.StatusText:
                chat.HasVoiceConsent?chat.StatusText:"Your guide is here when you're ready. Enable voice to talk, or simply enjoy the room.";
            if(body!=lastCaption){lastCaption=body;captionScroll=Vector2.zero;}
            if(largeCaption==null)largeCaption=new GUIStyle(ui.Text){fontSize=21};
            GUIStyle style=largerCaptions?largeCaption:ui.Text;
            Rect viewport=new Rect(r.x+18,r.y+47,r.width-36,r.height-89);float textHeight=Mathf.Max(viewport.height,style.CalcHeight(new GUIContent(body),viewport.width-18));
            captionScroll=GUI.BeginScrollView(viewport,captionScroll,new Rect(0,0,viewport.width-18,textHeight));
            GUI.Label(new Rect(0,0,viewport.width-18,textHeight),body,style);GUI.EndScrollView();
            float y=r.y+r.height-34;
            if(GUI.Button(new Rect(r.x+16,y,143,25),"V   Voice controls",ui.Button))chat.OpenPanel();
            if(GUI.Button(new Rect(r.x+169,y,94,25),"T   Type",ui.Button))chat.OpenTyping();
            if(GUI.Button(new Rect(r.x+273,y,128,25),"Tab   Not now",ui.Button))chat.PauseFromHud();
            GUI.Label(new Rect(r.x+415,y+6,138,20),chat.IsMuted?"M  Unmute mic":"M  Mute mic",ui.Small);
        }
        public void DrawSettings()
        {
            var ui=Theme;GUILayout.Space(12);GUILayout.Label("Make the room comfortable for you",ui.Text);
            showJourney=GUILayout.Toggle(showJourney," Show the gentle checklist",chat.ToggleStyle);
            showCaptions=GUILayout.Toggle(showCaptions," Show conversation captions",chat.ToggleStyle);
            largerCaptions=GUILayout.Toggle(largerCaptions," Larger caption text",chat.ToggleStyle);
            GUILayout.Label("Panel opacity",ui.Small);panelOpacity=GUILayout.HorizontalSlider(panelOpacity,.65f,1);
            var music=BackgroundMusicPlayer.Instance;
            if(music!=null)
            {
                GUILayout.Space(12);GUILayout.Label("Music · "+music.TrackTitle,ui.Text);
                music.Volume=GUILayout.HorizontalSlider(music.Volume,0,.5f);
                if(GUILayout.Button(music.IsPaused?"Resume music (P)":"Pause music (P)",ui.Button))music.TogglePause();
            }
            GUILayout.Space(16);GUILayout.Label("F1 Settings · J Checklist · P Music\nV Voice controls · T Type · M Mute mic · X / Tab Pause voice\nWASD Walk · Mouse Look · E Interact · Space Stand\nEsc Cursor / close panel · Enter Resume exploring",ui.Small);
            GUILayout.Space(12);GUILayout.Label("Checklist steps are optional. Progress and captions are kept only for this play run. User captions arrive when the speech service transcribes your turn; no extra recording service is added.",ui.Small);
        }
        public static string TimeLabel(float seconds)
        {int value=Mathf.Max(0,Mathf.FloorToInt(seconds));return (value/60)+":"+(value%60).ToString("00");}
    }
}
