using System;
using System.Collections.Generic;

namespace TheLastWatch.Integrations
{
    // Main-thread, memory-only presentation state. No additional speech service or microphone reader.
    public sealed class WellnessCaptions
    {
        public enum Speaker { Waiting, Player, Companion, Listening }
        public Speaker Who { get; private set; } = Speaker.Waiting;
        public string Message { get; private set; } = "...";
        public int EventId { get; private set; }
        public string[] Pages { get; private set; } = new[]{"..."};
        public int Page { get; private set; }
        private float changedAt, pageAt;
        private bool wasSpeaking;
        public void Reset() { wasSpeaking=false; Set(Speaker.Waiting,"...",0,0); }
        public void User(string text,int id,float now) { if(!string.IsNullOrWhiteSpace(text))Set(Speaker.Player,text,id,now); }
        public void Agent(string text,int id,float now) { if(!string.IsNullOrWhiteSpace(text))Set(Speaker.Companion,text,id,now); }
        public void Correct(string text,int id,float now)
        { if(Who==Speaker.Companion&&EventId==id&&!string.IsNullOrWhiteSpace(text))Set(Speaker.Companion,text,id,now); }
        public void Interrupt(float now) { wasSpeaking=false;Set(Speaker.Waiting,"...",0,now); }
        private void Set(Speaker who,string text,int id,float now)
        {
            Who=who;Message=text;EventId=id;Pages=Split(text,140);Page=0;changedAt=pageAt=now;
        }
        public void Tick(bool agentSpeaking,bool userSpeaking,bool muted,float now)
        {
            if(agentSpeaking)wasSpeaking=true;
            else if(wasSpeaking)
            {wasSpeaking=false;if(Who==Speaker.Companion)Set(Speaker.Waiting,"...",0,now);}
            if(!agentSpeaking&&!muted&&userSpeaking && (Who!=Speaker.Player||now-changedAt>1.5f))
            {if(Who!=Speaker.Listening)Set(Speaker.Listening,"Listening…",0,now);}
            else if(Who==Speaker.Listening&&(!userSpeaking||muted))Set(Speaker.Waiting,"...",0,now);
            if(!agentSpeaking&&((Who==Speaker.Player&&now-changedAt>8)||(Who==Speaker.Companion&&now-changedAt>15)))
                Set(Speaker.Waiting,"...",0,now);
            if(Page<Pages.Length-1&&now-pageAt>Math.Max(2.5f,Pages[Page].Length/16f)){Page++;pageAt=now;}
        }
        public static string[] Split(string text,int maxChars)
        {
            if(string.IsNullOrEmpty(text))return new[]{"..."};
            maxChars=Math.Max(32,maxChars);var pages=new List<string>();int start=0;
            while(start<text.Length)
            {
                int end=Math.Min(start+maxChars,text.Length);
                if(end<text.Length)
                {
                    int split=text.LastIndexOf(' ',end-1,end-start);
                    if(split>start+maxChars/2)end=split;
                    // Never split a UTF-16 surrogate pair (for example, a transcribed emoji).
                    if(end>start&&char.IsHighSurrogate(text[end-1])&&char.IsLowSurrogate(text[end]))end--;
                }
                pages.Add(text.Substring(start,end-start).Trim());start=end;
                while(start<text.Length&&char.IsWhiteSpace(text[start]))start++;
            }
            return pages.ToArray();
        }
    }
}
