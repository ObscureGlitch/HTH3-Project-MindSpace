#!/usr/bin/env node

const args = new Map();
for (let i = 2; i < process.argv.length; i += 1) {
  const key = process.argv[i];
  const value = process.argv[i + 1];
  if (key.startsWith('--')) {
    args.set(key, value && !value.startsWith('--') ? value : 'true');
    if (value && !value.startsWith('--')) i += 1;
  }
}

const emit = (message) => process.stdout.write(`${JSON.stringify(message)}\n`);
const finite = (value) => value != null && Number.isFinite(Number(value)) ? Number(value) : null;
const latest = (values) => Array.isArray(values) && values.length > 0 ? values.at(-1) : null;
const bounded = (value, fallback = '') => String(value ?? fallback).replace(/[\r\n]+/g, ' ').slice(0, 240);
const option = (name, fallback) => {
  const value = Number.parseInt(args.get(name) ?? '', 10);
  return Number.isFinite(value) ? value : fallback;
};

if (args.has('--self-test')) {
  emit({ type: 'status', statusCode: 3 });
  emit({
    type: 'metrics', timestampUs: 1, hasPulse: true, pulseBpm: 72,
    pulseConfidence: 92, pulseStable: true, hasBreathing: true,
    breathingRate: 12, breathingConfidence: 90, breathingStable: true,
    hasHrv: true, hrvRmssd: 42, hrvSdnn: 51, hrvConfidence: 85,
  });
  process.exit(0);
}

const apiKey = (process.env.TLW_PRESAGE_API_KEY || process.env.SMARTSPECTRA_API_KEY || '').trim();
if (!apiKey) {
  emit({
    type: 'error', errorCode: -1, retryable: false,
    message: 'Set TLW_PRESAGE_API_KEY to a rotated Presage key before enabling measurements.',
  });
  process.exit(2);
}

let sdk;
let stopping = false;
let lastEmissionMs = 0;
let lastValidationCode = null;
let lastValidationMs = 0;

const redact = (value) => bounded(String(value ?? '').replaceAll(apiKey, '[redacted]'));
const stop = async (exitCode = 0) => {
  if (stopping) return;
  stopping = true;
  try {
    if (sdk) await sdk.stopAsync();
  } catch {
    // Teardown is best-effort; never expose native error details or credentials.
  }
  try {
    if (sdk) await sdk.destroy();
  } catch {
    // The OS will reclaim the sidecar after exit.
  }
  process.exit(exitCode);
};

try {
  const {
    SmartSpectraSDK, SmartSpectraLogLevel, breathingMetrics, cardioMetrics, decodeMetrics,
  } = await import('@smartspectra/node-sdk');
  sdk = new SmartSpectraSDK({
    apiKey,
    requestedMetrics: [...breathingMetrics, ...cardioMetrics],
    enableTelemetry: false,
    logLevel: SmartSpectraLogLevel.kError,
  });

  sdk.on('processingStatus', (status) => {
    if (stopping) return;
    emit({ type: 'status', statusCode: finite(status) ?? -1 });
  });

  sdk.on('validationStatus', (code, timestampUs, hint) => {
    if (stopping) return;
    const now = Date.now();
    if (code === lastValidationCode && now - lastValidationMs < 2000) return;
    lastValidationCode = code;
    lastValidationMs = now;
    emit({
      type: 'validation', validationCode: finite(code) ?? -1,
      timestampUs: finite(timestampUs) ?? 0, hint: redact(hint || 'Adjust camera position or lighting.'),
    });
  });

  sdk.on('metrics', (buffer, timestampUs) => {
    if (stopping || (lastValidationCode !== null && lastValidationCode !== 0)) return;
    const now = Date.now();
    if (now - lastEmissionMs < 500) return;
    const metrics = decodeMetrics(buffer);
    if (!metrics || Buffer.isBuffer(metrics)) return;

    const pulse = latest(metrics.cardio?.pulseRate);
    const breathing = latest(metrics.breathing?.rate);
    const hrv = latest(metrics.cardio?.hrv);
    if (!pulse && !breathing && !hrv) return;

    lastEmissionMs = now;
    emit({
      type: 'metrics',
      timestampUs: finite(timestampUs) ?? 0,
      hasPulse: finite(pulse?.value) !== null,
      pulseBpm: finite(pulse?.value) ?? 0,
      pulseConfidence: finite(pulse?.confidence) ?? 0,
      pulseStable: Boolean(pulse?.stable),
      hasBreathing: finite(breathing?.value) !== null,
      breathingRate: finite(breathing?.value) ?? 0,
      breathingConfidence: finite(breathing?.confidence) ?? 0,
      breathingStable: Boolean(breathing?.stable),
      hasHrv: finite(hrv?.rmssd) !== null,
      hrvRmssd: finite(hrv?.rmssd) ?? 0,
      hrvSdnn: finite(hrv?.sdnn) ?? 0,
      hrvConfidence: finite(hrv?.confidence) ?? 0,
    });
  });

  sdk.on('error', (code, message, retryable) => {
    if (stopping) return;
    emit({
      type: 'error', errorCode: finite(code) ?? -1,
      retryable: Boolean(retryable), message: redact(message || 'SmartSpectra measurement failed.'),
    });
  });

  sdk.useCamera({
    deviceIndex: option('--camera-index', 0),
    width: option('--width', 1280),
    height: option('--height', 720),
    fps: option('--fps', 30),
  });
  sdk.start();
  emit({ type: 'ready', sdkVersion: bounded(SmartSpectraSDK.version, 'unknown') });
} catch (error) {
  emit({
    type: 'error', errorCode: finite(error?.code) ?? -1,
    retryable: Boolean(error?.retryable), message: redact(error?.message || 'Unable to start SmartSpectra.'),
  });
  await stop(1);
}

process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  if (String(chunk).split(/\r?\n/).some((line) => line.trim().toLowerCase() === 'stop')) void stop(0);
});
process.stdin.on('end', () => void stop(0));
process.on('SIGINT', () => void stop(0));
process.on('SIGTERM', () => void stop(0));
