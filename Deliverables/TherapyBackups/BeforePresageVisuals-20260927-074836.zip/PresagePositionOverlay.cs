using UnityEngine;

namespace TheLastWatch.UI
{
    public static class PresagePositionOverlay
    {
        // Match ScaleToFit's letterboxing so the guide always sits inside the camera image.
        public static Rect ImageRect(Rect viewport, float aspect)
        {
            float w = Mathf.Min(viewport.width, viewport.height * aspect);
            float h = w / aspect;
            return new Rect(viewport.center.x - w / 2, viewport.center.y - h / 2, w, h);
        }
        public static void Draw(Rect viewport, Texture image, bool positioned, GUIStyle label)
        {
            Rect r = ImageRect(viewport, image != null ? (float)image.width / image.height : 16f / 9);
            Color color = positioned ? new Color(.48f, 1, .68f, .95f) : new Color(1, .83f, .46f, .95f);
            Vector2 previous = Vector2.zero;
            for (int i = 0; i <= 64; i++)
            {
                float angle = i * Mathf.PI * 2 / 64;
                Vector2 p = Point(r, .5f + Mathf.Sin(angle) * .09f, .31f + Mathf.Cos(angle) * .22f);
                if (i > 0) Line(previous, p, color);
                previous = p;
            }
            Vector2[] body = {
                new Vector2(.455f,.53f), new Vector2(.445f,.59f), new Vector2(.34f,.62f),
                new Vector2(.25f,.67f), new Vector2(.20f,.76f), new Vector2(.18f,.94f),
            };
            for (int side = 0; side < 2; side++) for (int i = 1; i < body.Length; i++)
            {
                Vector2 a = body[i-1], b = body[i];
                if (side == 1) { a.x = 1-a.x; b.x = 1-b.x; }
                Line(Point(r,a.x,a.y), Point(r,b.x,b.y), color);
            }
            for (int i = 0; i < 10; i++)
                Line(Point(r,.29f+i*.043f,.93f),Point(r,.31f+i*.043f,.93f),color);
            GUI.Label(new Rect(r.x+8,r.y+6,r.width-16,22),"Fit your face inside the oval",label);
            GUI.Label(new Rect(r.x+8,r.yMax-25,r.width-16,22),"Keep shoulders and upper chest in view",label);
        }
        private static Vector2 Point(Rect r,float x,float y) => new Vector2(r.x+x*r.width,r.y+y*r.height);
        private static void Line(Vector2 a,Vector2 b,Color color)
        {
            Matrix4x4 matrix=GUI.matrix;
            Vector2 delta=b-a;
            GUIUtility.RotateAroundPivot(Mathf.Atan2(delta.y,delta.x)*Mathf.Rad2Deg,a);
            WellnessUiTheme.Fill(new Rect(a.x,a.y-2,delta.magnitude,4),new Color(0,0,0,.65f));
            WellnessUiTheme.Fill(new Rect(a.x,a.y-1,delta.magnitude,2),color);
            GUI.matrix=matrix;
        }
    }
}
