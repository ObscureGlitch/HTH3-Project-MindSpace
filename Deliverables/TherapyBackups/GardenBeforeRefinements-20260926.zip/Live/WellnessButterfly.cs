using UnityEngine;

namespace TheLastWatch.Environment
{
    [DisallowMultipleComponent]
    public sealed class WellnessButterfly : MonoBehaviour
    {
        public Transform leftWing, rightWing;
        public Vector3 home;
        public float radius = 1, phase;
        public void Sample(float seconds)
        {
            float a = seconds * .43f + phase;
            transform.localPosition = home + new Vector3(Mathf.Cos(a) * radius, Mathf.Sin(a * 2.3f) * .24f, Mathf.Sin(a) * radius * .72f);
            transform.localRotation = Quaternion.Euler(0, -a * Mathf.Rad2Deg, 0);
            float flap = (.25f + Mathf.Sin(seconds * 13 + phase) * .9f) * Mathf.Rad2Deg;
            if (leftWing != null) leftWing.localRotation = Quaternion.Euler(0, 0, flap);
            if (rightWing != null) rightWing.localRotation = Quaternion.Euler(0, 0, -flap);
        }
        private void Update() => Sample(Time.time);
    }
}
